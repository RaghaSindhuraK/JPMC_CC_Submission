//
//  MockWeatherDataManger.swift
//  WeatherApp_JPMC_CCTests
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/31/24.
//

import Foundation
@testable import WeatherApp_JPMC_CC

class MockWeatherDataManger: WeatherDataManager {
    
    var didAPISucceed = true
    
    override func fetchWeather(with cityName: String, completion: @escaping (WeatherSearchDataModel?) -> Void) {
        if didAPISucceed {
            completion(WeatherSearchDataModel(
                coord: WeatherCoordModel(lon: -74.006, lat: 40.7143),
                weather: [WeatherCondition(id: 801, main: "Clouds", description: "few clouds", icon: "02n")],
                base: "stations",
                main: WeatherTemperature(temp: 301.19, feels_like: 302.89, temp_min: 297.42, temp_max: 303.12, pressure: 1010, humidity: 62),
                visibility: 10000,
                clouds: WeatherCloudModel(all: 20),
                dt: 1694131437,
                sys: WeatherSystemDetails(type: 1, id: 4610, country: "US", sunrise: 1694082526, sunset: 1694128793),
                timezone:  -14400,
                id: 5128581,
                name: "New York",
                cod: 200
            ))
        } else {
            completion(nil)
        }
    }
    
    override func getWeatherForCurrentLocation(completion: @escaping (WeatherSearchDataModel?) -> Void) {
        if didAPISucceed {
            completion(WeatherSearchDataModel(
                coord: WeatherCoordModel(lon: -74.006, lat: 40.7143),
                weather: [WeatherCondition(id: 801, main: "Clouds", description: "few clouds", icon: "02n")],
                base: "stations",
                main: WeatherTemperature(temp: 301.19, feels_like: 302.89, temp_min: 297.42, temp_max: 303.12, pressure: 1010, humidity: 62),
                visibility: 10000,
                clouds: WeatherCloudModel(all: 20),
                dt: 1694131437,
                sys: WeatherSystemDetails(type: 1, id: 4610, country: "US", sunrise: 1694082526, sunset: 1694128793),
                timezone:  -14400,
                id: 5128581,
                name: "New York",
                cod: 200
            ))
        } else {
            completion(nil)
        }
    }
    
}

