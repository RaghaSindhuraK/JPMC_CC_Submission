//
//  WeatherApp_JPMC_CCTests.swift
//  WeatherApp_JPMC_CCTests
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/29/24.
//

import Testing
@testable import WeatherApp_JPMC_CC

struct WeatherApp_JPMC_CCTests {

    @Test func testExample() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
