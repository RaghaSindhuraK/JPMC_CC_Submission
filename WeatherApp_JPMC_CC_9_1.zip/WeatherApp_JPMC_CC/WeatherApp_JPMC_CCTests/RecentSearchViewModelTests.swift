//
//  RecentSearchViewModelTests.swift
//  WeatherApp_JPMC_CCTests
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/31/24.
//

import XCTest
@testable import WeatherApp_JPMC_CC

final class RecentSearchViewModelTests: XCTestCase {
    var viewModel: RecentSearchViewModel!
    var mockDataManager: RecentSearchMockDataManager!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        mockDataManager = RecentSearchMockDataManager()
        viewModel = RecentSearchViewModel(with: mockDataManager)
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }

    //Testing cityName at Different indices
    func testViewModelSetUp() {
        viewModel.getHistory()
        
        XCTAssertEqual(viewModel.cityName(at: -1), "", "city name is wrong")
        XCTAssertEqual(viewModel.cityName(at: 0), "New York, 82 Fahrenheit", "city name is wrong")
        XCTAssertEqual(viewModel.cityName(at: 1), "Dallas, 82 Fahrenheit", "city name is wrong")
        XCTAssertEqual(viewModel.cityName(at: 500), "", "city name is wrong")
    }
}
