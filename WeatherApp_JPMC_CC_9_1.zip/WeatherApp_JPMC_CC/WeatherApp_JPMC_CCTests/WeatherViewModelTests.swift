//
//  WeatherViewModelTests.swift
//  WeatherApp_JPMC_CCTests
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/31/24.
//

import XCTest
@testable import WeatherApp_JPMC_CC


final class WeatherViewModelTests: XCTestCase {
    var weatherViewModel: WeatherViewModel!
    var mockWeatherDataManger: MockWeatherDataManger!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        mockWeatherDataManger = MockWeatherDataManger()
        weatherViewModel = WeatherViewModel(with: mockWeatherDataManger)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        weatherViewModel = nil
    }

    //Testing fetch weather by city name - to get City Name, Image, Min- max Temperature,Temperature and Weather condition
    func testFetchBycity() {
        weatherViewModel.fecthWeatherByCity(searchText: "Dallas")
        
        XCTAssertEqual(weatherViewModel.cityName, "New York", "CityName is not correct.")
        XCTAssertEqual(weatherViewModel.imageUrl, "https://openweathermap.org/img/wn/02n@2x.png", "Url is not correct.")
        XCTAssertEqual(weatherViewModel.maxTemperature, "H: 85", "maxTemp is not correct.")
        XCTAssertEqual(weatherViewModel.minTemperature, "L: 75", "minTemp is not correct.")
        XCTAssertEqual(weatherViewModel.temperatureLabel, "82", "temp is not correct.")
        XCTAssertEqual(weatherViewModel.weatherCondition, "Clouds", "Condition is not correct.")
        
     
        mockWeatherDataManger = MockWeatherDataManger()
        mockWeatherDataManger.didAPISucceed = false
        weatherViewModel = WeatherViewModel(with: mockWeatherDataManger)
        
        XCTAssertNil(weatherViewModel.cityName, "CityName is not correct.")
        XCTAssertEqual(weatherViewModel.imageUrl, "", "Url is not correct.")
        XCTAssertEqual(weatherViewModel.maxTemperature, "H: -459", "maxTemp is not correct.")
        XCTAssertEqual(weatherViewModel.minTemperature, "L: -459", "minTemp is not correct.")
        XCTAssertEqual(weatherViewModel.temperatureLabel, "-459", "temp is not correct.")
        XCTAssertEqual(weatherViewModel.weatherCondition, "", "Condition is not correct.")
    }
    
    //Testing fetch weather by Location - to get City Name, Image, Min- max Temperature,Temperature and Weather condition
    func testFetchByLocation() {
        weatherViewModel.fetchWeatherBylocation()
        
        XCTAssertEqual(weatherViewModel.cityName, "New York", "CityName is not correct.")
        XCTAssertEqual(weatherViewModel.imageUrl, "https://openweathermap.org/img/wn/02n@2x.png", "Url is not correct.")
        XCTAssertEqual(weatherViewModel.maxTemperature, "H: 85", "maxTemp is not correct.")
        XCTAssertEqual(weatherViewModel.minTemperature, "L: 75", "minTemp is not correct.")
        XCTAssertEqual(weatherViewModel.temperatureLabel, "82", "temp is not correct.")
        XCTAssertEqual(weatherViewModel.weatherCondition, "Clouds", "Condition is not correct.")
        
     
        mockWeatherDataManger = MockWeatherDataManger()
        mockWeatherDataManger.didAPISucceed = false
        weatherViewModel = WeatherViewModel(with: mockWeatherDataManger)
        
        XCTAssertNil(weatherViewModel.cityName, "CityName is not correct.")
        XCTAssertEqual(weatherViewModel.imageUrl, "", "Url is not correct.")
        XCTAssertEqual(weatherViewModel.maxTemperature, "H: -459", "maxTemp is not correct.")
        XCTAssertEqual(weatherViewModel.minTemperature, "L: -459", "minTemp is not correct.")
        XCTAssertEqual(weatherViewModel.temperatureLabel, "-459", "temp is not correct.")
        XCTAssertEqual(weatherViewModel.weatherCondition, "", "Condition is not correct.")
    }

}



