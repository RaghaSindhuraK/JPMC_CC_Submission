//
//  RecentSearchMockDataManager.swift

//  WeatherApp_JPMC_CCTests
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/31/24.
//

import Foundation
@testable import WeatherApp_JPMC_CC

class RecentSearchMockDataManager: 
