//
//  WeatherViewModel.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/30/24.
//

import Foundation

protocol WeatherViewRefresh: NSObject {
    func refreshView()
    func refreshFailed()
}


class WeatherViewModel {
    weak var delegate: WeatherViewRefresh?
    
    var weatherDataManager = WeatherDataManager()
    var weatherSearchDataModel: WeatherSearchDataModel?
    
    convenience init(with dataManger: WeatherDataManager) {
        self.init()
        weatherDataManager = dataManger
    }
    
    // Kelvin to Farhenheit conversion
    private func convertunits(value: Double) -> Int {
        Int(((value - 273.15) * 9/5) + 32)
    }
    
    // Model object for Weather UI
    var cityName: String? {
        weatherSearchDataModel?.name
    }
    var temperatureLabel: String? {
        let value = convertunits(value: weatherSearchDataModel?.main.temp ?? 0.0)
        return "\(value)"
    }
    var weatherCondition: String? {
        "\(weatherSearchDataModel?.weather.first?.main ?? "")"
    }
    var maxTemperature: String? {
        let value = convertunits(value: weatherSearchDataModel?.main.temp_max ?? 0.0)
        return "H: \(value)"
    }
    var minTemperature: String? {
        let value = convertunits(value: weatherSearchDataModel?.main.temp_min ?? 0.0)
        return "L: \(value)"
    }
    var imageUrl: String {
        let urlString = "https://openweathermap.org/img/wn/%@@2x.png"
        guard let imagename = weatherSearchDataModel?.weather.first?.icon else { return "" }
        return String(format: urlString, imagename)
    }
    
    //DataManager method to fetch weather by city
    func fecthWeatherByCity(searchText: String) {
        weatherDataManager.fetchWeather(with: searchText) { [weak self] model in
            self?.weatherSearchDataModel = model
            model == nil ? self?.delegate?.refreshFailed() : self?.delegate?.refreshView()
        }
    }
    //DataManager method to fetch weather by current location
    func fetchWeatherBylocation() {
        weatherDataManager.getWeatherForCurrentLocation { [weak self] model in
            self?.weatherSearchDataModel = model
            model == nil ? self?.delegate?.refreshFailed() : self?.delegate?.refreshView()
        }
        
    }
}
